#Taller de ingenieria 2- Desafio 2 
#Estudiantes: David Mansilla y Elvis Guerrero
#Profesores: Luz Cardona y Gabriel Nuñez
"------------------------------------------------------------------------------------------------------"
N=0
M=0
puertoS=[]
"Paso 1"
#Creacion del menu interactivo
def opciones():
    print("Hola usuario, porfavor ingrese una opcion para elegir")
    print("Ingrese 1 para Generar el estado inicial del puerto seco")
    print("Ingrese 2 para Imprimir el estado del puerto seco ")
    print("Ingrese 3 para Ubicar un contenedor ")
    print("Ingrese 4 para Incluir un contenedor ")
    print("Ingrese 5 para Retirar un contenero")
    print("Ingrese 0 para cerrar su jornada laboral")
    return

"Paso2"
#Creacion del estado inicial
def opcion1(N,M):
    puertoS=[]
    N=int(input("Ingrese la cantidad de contenedores maximos que soportara el puerto:"))
    M=int(input("Ingrese la cantidad de pilas maximas que soportara el puerto:"))
    if M>N or M==N:
        for i in range(M):
            cont=[]
            for o in range(N):
                cont.append(input("Ingrese el numero de la carga y nombre de la empresa separados por un /: ")) 
            cont.append("    V   ")
            puertoS.append(cont)
    else:
            for i in range(M):
                cont = []
                for o in range(N):
                    if i == 0 and o == N-1:
                      cont.append(0)
                    else:
                      cont.append(input("Ingrese Número/NombreEmpresa: "))
                puertoS.append("   V   ")
                puertoS.append(cont)
    return puertoS

def impuertoS(puertoS,N,M):

	i = N-1
	while (i >= 0):
		o = M-1
		print("\ ", end = " ")
		while (o >= 0):
			print (puertoS[o][i], " \ ", end=" ")
			o = o - 1
		print("")
		i = i - 1

puertoS = opcion1(N,M)
impuertoS(puertoS, N+1, M)


           

    
