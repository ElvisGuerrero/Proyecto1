# For



for i in range(10):  # range(numero) -> numeros desde el 0 hasta numero-1
	print("El valor de variable es: ", i)


nombre = "Gabriel"

k = 1
for i in nombre:
	print("La letra en la posición ", k, "es: ",i)
	k = k + 1
	
