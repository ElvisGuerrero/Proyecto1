from random import randint

numeros = []

for i in range(25):
	numeros.append(randint(1,100))

print(numeros)



i = 0
j = 0

while(j < 25):
	i = j + 1
	while(i < 25):
		if numeros[i] <= numeros[j]: # encontramos un elmento que es menor a que inicialmente definidmos como menor
			temp = numeros[i]
			numeros[i] = numeros[j]
			numeros[j] = temp
		
		i = i + 1
	j = j + 1
	
print(numeros)
