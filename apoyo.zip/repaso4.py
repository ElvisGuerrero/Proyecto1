# listas


"""
ID = [223,333,214]
Nombre = ["Lybx", "YTDH", "HHFJ"]
            #0      1       2   
            
            
largo = len(ID)
i = 0

while(i<largo):
	print("el elemento con ID: ", ID[i], " es:", Nombre[i])
	i = i + 1
'''
##
"""
ID = []
nombre = []

print("¿Cuantos elementos quiere incorpor?")
N = int(input())

for i in range(N):
	cod = int(input("Ingrese código del elemento: "))
	ID.append(cod)
	nam = input("Ingrese nombre del elemento: ")
	nombre.append(nam)

print(ID,nombre)


##
"""
ID = [14, 45, 455, 568, 47]
Nombre = ['hhd', 'jdhjd', 'asa', 'qwerty', 'sdgaa']

ubicacion = ID.index(455)

print("El nombre del código 455 es :", Nombre[ubicacion])

"""
##
"""
ID = [14, 45, 455, 568, 47]
Nombre = ['hhd', 'jdhjd', 'asa', 'qwerty', 'sdgaa']

ID2 = []
Nombre2 = []

ubicacion = ID.index(455)
print("El nombre del código 455 es :", Nombre[ubicacion])

print(ID, Nombre)

ID2.append(ID[ubicacion])
Nombre2.append(Nombre[ubicacion])

del ID[ubicacion]
del Nombre[ubicacion]

print(ID, Nombre)
print(ID2, Nombre2)

"
















