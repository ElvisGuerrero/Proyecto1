# Funciones


def nombrefuncion(ciclos, opcionUsuario):
	# acciones
	
	for i in range(ciclos):
		print("El usuario indicó ", ciclos," ciclos, y su opción del menú fue : ", opcionUsuario)
	
	
def nombrefuncion2():
	# acciones
	print ("Este es el menú de mi programa: ")
	print ("opc 1: lala")
	print ("opc 2: lalala")
	print ("opc 3: lelele")
	print ("opc 4: lilili ")
	print ("opc 5: lululu ")
	print ("opc 6: lololo")
	
	opcion = int(input("ingrese su opción segun el menu: "))
	return opcion


######### Función Principal #############33


print("Ingrese un valor entero para cantidad de ciclos: ")
valor = int(input())

#opcMenu = nombrefuncion2()
#nombrefuncion(valor,opcMenu)

for i in range(10):
	opcMenu = nombrefuncion2()
	nombrefuncion(valor,opcMenu)

