

# For  y while

#while
#variables que llamamos contadores/acumuladores
#funciona mientras se cumpla una condición


i = int(input("Ingrese un valor positivo para imprimir o negativo para salir: "))
# i = 10

while (i>0):
	print("El usuario ingresó un valor positivo")
	i = int(input("Ingrese un valor positivo para imprimir o negativo para salir: "))

print("El usuario ingreso un valor negativo, por lo tanto se termina el ciclo")

j = int (input("¿Cuantos ciclos se requieren?: "))

k = 0

while(k<j):
	print ("Ciclo ", k )
	k = k + 1
